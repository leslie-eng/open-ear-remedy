import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';
import { pool } from './db.js';
import { errorHandler } from './middleware.js';
import authRoutes from './routes/auth.js';
import userRoutes from './routes/user.js';
import callsRoutes from './routes/calls.js';
import chatRoutes from './routes/chat.js';
import paymentsRoutes, { paystackWebhookHandler } from './routes/payments.js';
import appointmentsRoutes from './routes/appointments.js';
import adminRoutes from './routes/admin.js';
import notificationsRoutes from './routes/notifications.js';
import uploadsRoutes from './routes/uploads.js';

fs.mkdirSync(config.uploadDir, { recursive: true });

const app = express();

app.use(
  cors({
    origin: (origin, cb) => {
      if (!origin || config.corsOrigins.includes(origin)) {
        cb(null, true);
      } else {
        cb(null, false);
      }
    },
    credentials: true,
  }),
);

app.post(
  '/api/payments/webhook',
  express.raw({ type: 'application/json' }),
  (req, _res, next) => {
    req.rawBody = req.body?.toString?.('utf8') || '';
    try {
      req.body = JSON.parse(req.rawBody);
    } catch {
      req.body = {};
    }
    next();
  },
  paystackWebhookHandler(),
);

app.use(express.json({ limit: '2mb' }));

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    database: Boolean(pool),
  });
});

app.use('/uploads', express.static(config.uploadDir));
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/calls', callsRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/payments', paymentsRoutes);
app.use('/api/appointments', appointmentsRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/uploads', uploadsRoutes);

app.use(errorHandler);

app.listen(config.port, () => {
  console.log(`Open Ear API listening on http://localhost:${config.port}`);
  if (!pool) {
    console.warn('WARNING: DATABASE_URL not set — API will fail on data routes');
  }
});
